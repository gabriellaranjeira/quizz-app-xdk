<?php
include_once("conn.php");

if(isset($_POST['con']) && $_POST['con'] == "con4545"){
	$nome = trim($_POST['nome']);
	$npeg = trim($_POST['npeg']);
	$alt = trim($_POST['alt']);
	$desc = trim($_POST['desc']);

	$sql = "INSERT INTO quiz(nome, descricao, alt) VALUES (
			:nome,
			:descricao,
			:alt)";
                                          
	$stmt = $conn->prepare($sql);
													  
	$stmt->bindParam(':nome', $nome, PDO::PARAM_STR); 
	$stmt->bindParam(':descricao', $desc, PDO::PARAM_STR); 
	$stmt->bindParam(':alt', $alt, PDO::PARAM_STR);                                    
	if($stmt->execute()){
		$consulta = $conn->prepare("SELECT id FROM quiz WHERE nome = :usr");
		$consulta->bindParam(':usr', $nome, PDO::PARAM_STR);
		if($consulta->execute()){
			if($consulta->rowCount() > 0){
				while($row = $consulta->fetch(PDO::FETCH_OBJ)){
					$id = $row->id;
				}
			}else{ echo "error!"; }
		}else{ echo "error!"; }

		for($x = 1;$x <= $npeg; $x++){
			$pergunta = "peg".$x;
			echo $_POST[$pergunta];
			$res = "res".$x;
			$sql = "INSERT INTO pergunta(id_quiz,
					pergunta,
					certo) VALUES (
	            	:id,
	            	:peg,
	            	:certo)";
	                                          
			$peg = $conn->prepare($sql);
			$peg->bindParam(':id', $id, PDO::PARAM_STR); 
			$peg->bindParam(':peg', $_POST[$pergunta], PDO::PARAM_STR);
			$peg->bindParam(':certo', $_POST[$res], PDO::PARAM_STR);  
			$peg->execute();
			$cons = $conn->prepare("SELECT id FROM pergunta WHERE id_quiz = :usr");
			$cons->bindParam(':usr', $id, PDO::PARAM_STR);
			if($cons->execute()){
				while($row = $cons->fetch(PDO::FETCH_OBJ)){
					$id_peg = $row->id;
				}
			}else{ echo "error!"; }
	
			for($i = 1;$i <= $alt;$i++){
				$tmp = "peg".$x."alt".$i;
				$sql = "INSERT INTO resposta(id_pergunta,
						resposta,
						n) VALUES (
		            	:id,
		            	:res,
		            	:n)";
		                                          
				$resp = $conn->prepare($sql);
				$resp->bindParam(':id', $id_peg, PDO::PARAM_STR); 
				$resp->bindParam(':res', $_POST[$tmp], PDO::PARAM_STR);
				$resp->bindParam(':n', $i, PDO::PARAM_STR);  
				$resp->execute();
			} 
			unset($resp);
			unset($peg);
			unset($res);
			unset($tmp);
			unset($sql);
			unset($pergu);
			unset($cons); 
			}
			header('location:home.php?msg=Quiz cadastrado com sucesso!');
		}else{
			header('location:home.php?msg=Não foi possivel cadastrar o quiz!');
	}
		
	}else{
		header('location:home.php');
	}

?>