<?php
	$nome = trim($_POST['nome']);
	$npeg = trim($_POST['npeg']);
	$alt = trim($_POST['alt']);
	$desc = trim($_POST['desc']);

	echo "<html><title>Configurando quiz</title> </head><body>";
	echo '<form method="post" action="add_quiz.php">'
	for($i = 0; $i <= $npeg ; $i++){
		echo 'Pergunta : <input type="text" name="peg'.$i.'"><br>';
		for($a = 0; $a <= $alt ; $a++){
			echo 'Pergunta : <input type="text" name="peg'.$i.'alt'.$a.'"><input type="radio" name="res'.$i.' value="'.$a.'"><br>';
		}
		echo "------------------------------------------------------------------------------------------------------";
	}

	echo '<input type="submit" value="Cadastrar">';
	echo "</form></body></html>";
?>