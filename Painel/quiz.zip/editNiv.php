<?php
include_once("conn.php");
$consulta = $conn->prepare("SELECT * FROM nivel");
$consulta->execute();
$conta = count($consulta->fetch(PDO::FETCH_OBJ));
for($i = 0;$i <= $conta;$i++){
		$niv = "pegc".$i;
		$pat = "patente".$i;
	    $stmt = $pdo->prepare('UPDATE niveis SET nivel = :n, patente = :pat WHERE id = :id');
  		if($stmt->execute(array(
    		':n'   => $_POST[$niv],
    		':pat' => $_POST[pat];,
    		':id' => $i
  		));){
  			header('location: home.php?msg=Niveis editados com sucesso!');
  		}else{
  			header('location: home.php?msg=Não foi possivel editar os niveis!');
  		}
}
?>