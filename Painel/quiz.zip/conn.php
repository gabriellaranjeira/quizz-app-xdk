<?php
try {

	$username = "root";
	$password = "";

    $conn = new PDO('mysql:host=localhost;dbname=instaBds', $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    echo "<script>alert('ERROR: ". $e->getMessage() ."');<script>";
}


?>